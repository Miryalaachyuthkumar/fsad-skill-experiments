package com.klu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Skill8Application {

    public static void main(String[] args) {
        SpringApplication.run(Skill8Application.class, args);
    }
}